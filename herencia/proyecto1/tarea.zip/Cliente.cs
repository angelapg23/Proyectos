﻿using System;

public class Cliente
{
    public int Id { get; set; }
    public string Nombre { get; set; }
    public int Telefono { get; set; }
    public string Ciudad { get; set; }
    public string Direccion { get; set; }


}

